# java challenges
## core java 
- develop a basic [inventory management system](https://github.com/ncodeit-java/challenges/blob/main/inventory%20management%20system) that can store and manage items in a store. The system should allow users to add new items, update existing items, view all items, and search for specific items by name. 


